package com.ge.ren.percentile;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


public class Percentile {
	private static String name = Constant.FILENAME;
	
	public static void main(String[] args) throws FileNotFoundException, IOException {

		if (args.length>0) {
			name = args[0];
		}

		List<Integer> latencies = selectItem( csvList(name), 1);

	    System.out.println(Constant.P90L + percentile(latencies, Constant.P90));
	    System.out.println("95% -> " + percentile(latencies, Constant.P95));
	    System.out.println("99% -> " + percentile(latencies, Constant.P99));
	}

	public static long percentile(List<Integer> latencies, double percentile) {
	    Collections.sort(latencies);
	    int index = (int) Math.ceil(percentile / 100.0 * latencies.size());
	    return latencies.get(index-1);
	}

	public static List<List<String>> csvList (String name) throws FileNotFoundException, IOException{
		List<List<String>> records = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(name))) {
		    String line;
		    while ((line = br.readLine()) != null) {
		        String[] values = line.split(",");
		        records.add(Arrays.asList(values));
		    }
		}
		return records;
	}
	
	public static List<Integer> selectItem(List<List<String>> csvList, int field) { 
		List<Integer> list = new ArrayList<Integer>() ;
		Iterator<List<String>> it = csvList.iterator();
		it.next();
		while (it.hasNext()) {
			List<String> rec;
			rec = it.next();
	        String value = rec.get(field);
	        list.add(Integer.parseInt(value));
	    }		
		return list; 
	}
}

class Constant{
	
	public static final String TITLE = "timeStamp,elapsed,label,responseCode,responseMessage,threadName,dataType,success,failureMessage,bytes,sentBytes,grpThreads,allThreads,URL,Latency,IdleTime,Connect\r\n"; 
	public static final String RECORD = "1613610555581,43,Access Token,200,OK,10.232.229.169:1099-Thread Group 1-1,text,true,,2904,379,1,1,http://apis-iac-feature.rendigital.apps.ge.com/auth/realms/master/protocol/openid-connect/token,43,0,33\r\n";
	public static final int P90 = 90;
	public static final int P95 = 95;
	public static final int P99 = 99;
	public static final String P90L = "90% -> ";
	public static final String P95L = "95% -> ";
	public static final String P99L = "99% -> ";
	public static final String FILENAME = "load.csv";
	
}