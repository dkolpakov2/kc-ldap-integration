# Jmeter integration for Kubernetes:
# GIT repo:
# https://github.build.ge.com/REN-AWS/ren-jmeter-kubernetes

# WIKI: https://devcloud.swcoe.ge.com/devspace/display/NBJXM/JMeter+Integration+for+Kubernetes

With JMeter, distributed testing is based on the server-agent model, where two kinds of JMeter instances interact over the network to perform one jmx test script. The first kind of JMeter instance is called the server. The JMeter server instance is the centralized injector of test session. This instance is the main controller that decides which JMX script is executed and when. 

For various reasons (e.g. limitation of local resources, network firewall) the server distributes load generation to other JMeter instances, called agents. The JMeter agents are “distributed” over the network. They receive the JMX script to be executed from the server.

## Prerequisites
1. Kubernetes  1.18 and up
1. Docker 2.5 and up

## The new namespace "pft" was created to run load test in dev environment
## creds to use that namespace within test cluster in dev:

- cluster:
    certificate-authority-data: LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUN5RENDQWJDZ0F3SUJBZ0lCQURBTkJna3Foa2lHOXcwQkFRc0ZBREFWTVJNd0VRWURWUVFERXdwcmRXSmwKY201bGRHVnpNQjRYRFRJeE1ERXlPREUxTXpVeU1Wb1hEVE14TURFeU5qRTFNelV5TVZvd0ZURVRNQkVHQTFVRQpBeE1LYTNWaVpYSnVaWFJsY3pDQ0FTSXdEUVlKS29aSWh2Y05BUUVCQlFBRGdnRVBBRENDQVFvQ2dnRUJBTU9SCk5paWMwTFRuUVJrM0RyeW5JK0hYQUVIcDh3QWQ4WkEybGNQY1hxdGU2d2tDeHhUVUJROFluY0NUUHBhWXV1eUwKU1h0d3BjUHk0Y1N1QVBIZGt4MFpNMW9QR2pZbDlIdFY5S0Q4ZkRlVndKL2s5VytBNHJNUTREd1htMmVXVm80egpFdjViYThQcnpyaDVEaHk3K2xiSitZNUlJYitQV0J4WVpJd3RmcHlwQ2p3Qi9RUnI2ZUFBUmdlbUE2Yy82MDhVCkk2S0hoQmVyVG1YajRXRzlvR01hT3FWZWJoVWZLT2ZWL0ZCSUhpMUozU2ZlL0FtcnpnT0tvL0hCMFh4M2Z0alUKcGxhdDROYWowMFY4LzZ5U3RySmRSMjJNQzBOWEFOV3N2cE91Vy8rRHg3WWtxWFFudFhFaWxkenB6U1ZheVB4UgpiZ3JTM1NzR1lpUkhuZWZnZktVQ0F3RUFBYU1qTUNFd0RnWURWUjBQQVFIL0JBUURBZ0trTUE4R0ExVWRFd0VCCi93UUZNQU1CQWY4d0RRWUpLb1pJaHZjTkFRRUxCUUFEZ2dFQkFEaitBNE05UU1GQ0RCSFVjQ3prL3JGNTVFbjEKQURPUExXQktScnVzcHplQmN4TS9NRTRWL0x6Q0RpdndDTFhQVTNRRTFzR2p1YTFqa1FmMER6aGRBb3hOWWJvMApsRnpkR1U4NFV5SmpjV3k0bkFkMmpyWW03alNMWHlyV2Z0cVZ3QWR0TzZldnhidm9ubzFNb0RGUXpXZ0RKdzJ3CmpqYlhLa3JrV0o4eENSaDVqeGVBQ3NVY3FkeFg2aHA1WkwyajZLWGtKUGh3T2tTMUl2QW91cDFWTVMwU0JPOXcKSFI0cFNjYi9OeUh3ampJMGlKNVdFTU1xdlZhdTcvcTFNa2k4NUJCajQ2OGJ4RHFtSWIyNm13QzZ0MVRUbkE2WQpxUWdocEhEeVNCVlVVT3Bla3RJczJqTUZuNElIZDdBM1NYYks1bHZMSHpRMTk5SXF4YTk5T3kzcWF2VT0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQo=
    server: https://B0A7353E19A7485A7B8593D27D603BB7.gr7.us-east-1.eks.amazonaws.com
  name: test

  - context:
    cluster: test
    user: test
  name: test
current-context: test

- name: test
  user:
    exec:
      apiVersion: client.authentication.k8s.io/v1alpha1
      args:
      - token
      - -i
      - renewables-uai3031357-pft-dev-cluster
      - -r
      - arn:aws:iam::164506192075:role/ren-eks-dna-ds-developer
      command: aws-iam-authenticator
      env:
      - name: AWS_PROFILE
        value: test

## Add to c:/Users/<your user ID>/gossamer3.yaml  next snippet:

- name: test
  url: https://fssfed.ge.com/fss
  username: "your user ID"
  provider: Ping
  mfa: Auto
  mfa_device: ""
  mfa_prompt: false
  skip_verify: false
  timeout: 10
  aws_urn: urn:amazon:webservices:mfa-extended
  aws_session_duration: 3600
  aws_profile: test
  role_arn: ""
  region: ""
  http_attempts_count: ""
  http_retry_delay: ""

##  add next snippet to the c:/.aws/credentials  :
[test]
aws_access_key_id        = 
aws_secret_access_key    = 
aws_session_token        = 
aws_security_token       = 
x_principal_arn          = 
x_security_token_expires =


## Then we can use next command to login to test cluster:
gossamer3 login -a test 

## Select an account: Account: geren-medrisk1-usaws (164506192075) / app/uai3031357-dna-ds-fed

## Once logged in to the test clucter you can check if any pods have been created by command:

kubectl get pod -n pft

# if no resources are found then we need to run next set of scripts shown below...

## run all scripts in order except the 1st script (it's been run once and all images have been created already):

```bash
# 1  ./update-helm.sh <user-name>	 Create cluster elements (pods, services, configMap) for load test   (it should be removed when test is done) for <user-name> (the user who will be using this set)
# 2	 ./start-jmeter-test.sh scripts/TaskNotes2.jmx <user-name>	 run Start test shell with test ...jmx file  (please see Example for the file TaskNotes2.jmx) will run test for <user-name>  (user-name example: dmitry )
# 3	./create-jmeter-stop.sh <user-name>	If all User needs to interrupt  the test this script can be used
# 4	 ./copy-jmeter-logs.sh <user-name>	 copy all logs into local system for analyzing
# 5	 ./delete-jmeter-cluster.sh <user-name>	 remove all pods, svc, deployments after test is completed

# 6	./delete-pods-force.sh	 Force to delete if pods have been placed in unrecoverable state
# 7	 ./get-cpu-usage.sh	Get CPU Usage (this is agent CPU usage not a Target server. In order to check the target server usage we need to use New Relic or target server top pod command )

```
# In order to run next test please use the ./create-jmeter-stop.sh script first.
# run clear prevous results command:
./clear-jmeter-logs.sh

# Attention:
## Plese delete all pods and service after test is done by using ./create-jmeter-delete.sh

## New Recil link:

https://one.newrelic.com/launcher/nrai.launcher


# Example of running script: "create-jmeter-cluster.sh" . It will give result logs in POC:

$ ./update-helm.sh
checking if kubectl is present
Client Version: v1.19.3
Server Version: v1.13.12-eks-3e38fc

>> Enter the name of the new tenant unique name, this will be used to create the namespace
pft

Creating Namespace: pft
namespace/pft created
Namspace pft has been created

Creating Jmeter agent nodes

Number of worker nodes on this cluster is  2

deployment.apps/jmeter-agent created
service/jmeter-agent-svc created
Creating Jmeter Server 
configmap/jmeter-load-test created
deployment.apps/jmeter-server created
Printout Of the jmeter Objects

   NAME                                 READY   STATUS    RESTARTS   AGE
>>pod/jmeter-agent-7f77d77c78-24b7w    1/1     Running   0          8s
>>pod/jmeter-agent-7f77d77c78-5gj7x    1/1     Running   0          8s

NAME                       TYPE        CLUSTER-IP   EXTERNAL-IP   PORT(S)              AGE
service/jmeter-agent-svc   ClusterIP   None         <none>        1099/TCP,50000/TCP   6s

NAME                            READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/jmeter-agent    2/2     2            2          8s
deployment.apps/jmeter-server   0/1     1            0           2s

NAME                                       DESIRED   CURRENT   READY   AGE
replicaset.apps/jmeter-agent-7f77d77c78    2         2         2       8s
replicaset.apps/jmeter-server-7c46fd56d8   1         1         0       2s
## End of example Logs

# # JMETER scale agents:
kubectl scale deployments jmeter-agent --replicas=10 -n pft 

# # Force to Delete pod:
kubectl delete pod jmeter-server-7c46fd56d8-zdsfd   --grace-period=0 --force --namespace pft


## ====================================================================
# Dashboard Setup (this item can be skipped, we have Relic dashboard):

Add Backend Listener to your test plan (Add -> Listener -> Backend Listener) and select org.apache.jmeter.visualizers.backend.influxdb.HttpMetricsSender
Provide in the Parameters table the InfluxDB settings, provide a name for the test, and specify which samplers to record.
For more details, see this :

https://jmeter.apache.org/usermanual/component_reference.html#Backend_Listener
https://jmeter.apache.org/usermanual/realtime-results.html

# Relic dashboard link:  https://insights.newrelic.com/accounts/2796857/dashboards/1490572?editing=true

# Kubernetes examples:
# JMETER scale:
kubectl scale deployments jmeter-agent-<username> --replicas=12 -n pft 
ls
winpty kubectl exec -it jmeter-agent-... -n pft -- bash
winpty kubectl exec -it jmeter-server-... -n pft -- bash

# Delete force:
kubectl delete pod jmeter-agent-pod-name   --grace-period=0 --force --namespace pft
kubectl delete pod pod-name --grace-period=0 --force --namespace pft

# Copy from local to pod:
>> kubectl cp /load_test.sh jmeter/jmeter-server-7984ff4fcc-tw6hl:/
>> kubectl cp load_test.sh -n jmeter jmeter-server-7984ff4fcc-tw6hl":/load_test.sh"

## After logs are copied into local PC, we can analyze it farther for percentile etc in different software like Excel or else.
 the  file testresults.jtl will have all logs needed for deep analizing.

 (see the screenshot link below: how to load csv file into Excel  and use Percentile)

https://github.build.ge.com/REN-AWS/ren-jmeter-kubernetes/tree/master/docs/Excel-CSV-file-load.png







