#!/usr/bin/env bash

# aws s3 cp $working_dir/test_$username s3://renewables-uai3031357-config-qa/testpft/test_$username --sse-kms-key-id arn:aws:kms:us-east-1:487459321624:key/435837b1-af36-4eab-b10c-31279d4de750 --sse aws:kms --acl bucket-owner-full-control  --no-verify-ssl 
# aws s3 ls s3://renewables-uai3031357-config-qa/testpft/ --no-verify-ssl 

FILE=  " cat aws s3 ls s3://renewables-uai3031357-config-qa/testpft/  --no-verify-ssl"
if [ ! -f "$FILE" ]; then
    echo "$FILE does not exist."
fi

searchDir="s3://renewables-uai3031357-config-qa/testpft/"
oldFiles=()
while IFS= read -r -d $'\0' foundFile; do
    oldFiles+=("$foundFile")
done < <(find "$searchDir" -maxdepth 1 -type f -print0 2> /dev/null)

if [[ ${#oldFiles[@]} -ne 0 ]]; then
    for file in "${oldFiles[@]}"; do
        curl -F ‘data=@"$file"’ UPLOAD_ADDRESS
    done
fi

fileName=$(kubectl get pods | awk '{print $1}' | grep -e "test")

echo " fileName-> $fileName"

# NOTE : Quote it else use array to avoid problems #
FILES="s3://renewables-uai3031357-config-qa/testpft/*"
for f in $FILES  --no-verify-ssl
do
  echo "Processing $f file..."
  # take action on each file. $f store current file name
  cat "$f"
done

# foo=$(kubectl get pods | awk '{print $1}' | grep -e "mysql")