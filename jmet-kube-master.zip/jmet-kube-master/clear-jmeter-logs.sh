#!/usr/bin/env bash
#Script created to launch Jmeter tests directly from the current terminal without accessing the jmeter master pod.
#It requires that you supply the path to the jmx file
#After execution, test script jmx file may be deleted from the pod itself but not locally.
# 

# kubectl scale deployments jmeter-clients -n pft --replicas=5

working_dir="`pwd`"
echo "work_dir:" $working_dir
#Get namesapce variable
tenant=`awk '{print $NF}' "$working_dir/pft_export"`
echo "tenant -> " $tenant
#Get Master pod details
master_pod=`kubectl get pod -n pft | grep 'jmeter-server' | awk '{print $1}'`

echo "master pod ->" $master_pod

JMETER_LOG_RESULTS="/testresults.jtl"
echo 'clear - Master log started...'
winpty kubectl -n $tenant exec -it $master_pod -- bash  -c 'rm /testresults.jtl'
#

echo 'clear master summary logs is done!'
