#!/usr/bin/env bash
#Script created to launch Jmeter tests directly from the current terminal without accessing the jmeter master pod.
#It requires that you supply the path to the jmx file
#After execution, test script jmx file may be deleted from the pod itself but not locally.
# 

# kubectl scale deployments jmeter-clients -n pft --replicas=5

working_dir="`pwd`"
echo "work_dir:" $working_dir
#Get namesapce variable
tenant=`awk '{print $NF}' "$working_dir/pft_export"`
echo "tenant -> " $tenant
#Get Master pod details
master_pod=`kubectl get pod -n pft | grep 'jmeter-server' | awk '{print $1}'`

echo "master pod ->" $master_pod

username=$(echo $1 | cut -d' ' -f 1)
echo "username=> "$username

JMETER_HOME="/jmeter.log"
JMETER_LOG_RESULTS="/testresults.jtl"
echo 'Copy Server - Master log started...'
kubectl -n $tenant cp $master_pod:$JMETER_HOME results$JMETER_HOME
kubectl -n $tenant cp $master_pod:$JMETER_LOG_RESULTS results$JMETER_LOG_RESULTS

echo 'clear - Master log started...'
winpty kubectl -n $tenant exec -it $master_pod -- bash  -c 'rm /testresults.jtl'
echo 'clear master summary logs is done!'

#  kubectl -n pft cp jmeter-server-79645d88bc-2ffnd:/testresults.jtl results/endure-157000-1pod.jlt
echo 'master copy is done'
# Copy agent logs
client_IP=$( kubectl get pods -n pft -o=jsonpath='{range .items[*]}{.metadata.name}{"\n"}')
echo 'Copy agentlogs started...'
echo 'client-ips-> ' $client_IP
JMETER_LOG="/jmeter-server.log"

for ip in $(echo $client_IP | sed "s/,/ /g")
    do
    if [[ "$ip" == *"agent-$username"* ]]; then
        echo "coping from ip-> " "$ip"
        kubectl -n $tenant cp $ip:$JMETER_LOG results/$ip$JMETER_LOG
    fi
done
echo 'agent copies are done!'
