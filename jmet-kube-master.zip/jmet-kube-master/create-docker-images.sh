#!/bin/bash -e

docker build --tag="jmeter-base:latest" -f docker/Dockerfile-base .
docker build --tag="jmeter-server:latest" -f docker/Dockerfile-server .
docker build --tag="jmeter-agent:latest" -f docker/Dockerfile-agent .

