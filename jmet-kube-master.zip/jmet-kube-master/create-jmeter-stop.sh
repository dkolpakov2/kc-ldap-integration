#!/usr/bin/env bash
#Script writtent to stop a running jmeter master test
#Kindly ensure you have the necessary kubeconfig

# Usage
# ./create-jmeter-stop.sh dmitry

working_dir=`pwd`

#Get namesapce variable
tenant=`awk '{print $NF}' $working_dir/pft_export`

echo 'stop test in namespace:' $tenant 

username=$(echo $1 | cut -d' ' -f 1)
echo "username= "$username

master_pod=`kubectl get po -n $tenant | grep jmeter-server-$username | awk '{print $1}'`
winpty kubectl exec -it -n $tenant $master_pod -- bash -c './jmeter/apache-jmeter-5.0/bin/stoptest.sh'
