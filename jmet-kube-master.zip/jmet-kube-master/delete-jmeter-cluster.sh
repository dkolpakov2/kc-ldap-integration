#!/usr/bin/env bash
#Script to remove all pods, services and jmeter namespace
#Kindly ensure you have the necessary kubeconfig
username=$(echo $1 | cut -d' ' -f 1)
echo "username=> "$username

# Get pods
client_IP=$( kubectl get pods -n pft -o=jsonpath='{range .items[*]}{.metadata.name}{"\n"}')
echo 'client-ip-> ' $client_IP

kubectl -n pft delete configMap jmeter-load-test-$username
echo 'configMap jmeter-load-test-'$username' deleted' 
kubectl -n pft delete deployment jmeter-server-$username
echo 'deployment jmeter-server-'$username' deleted' 
kubectl -n pft delete deployment jmeter-agent-$username
echo 'deployment jmeter-agent-'$username' deleted' 
kubectl -n pft delete svc jmeter-agent-svc-$username
echo 'svc jmeter-server-'$username' deleted' 
kubectl -n pft delete hpa jmeter-agent-$username
echo 'hpa jmeter-agent-'$username' deleted' 
#for ip in $(echo $client_IP | sed "s/,/ /g")
##    do
#    echo "$ip"
#    if [[ "$ip" == *"$username"* ]]; then
#        kubectl delete pod $ip --grace-period=0 --force -n pft
#        echo "deleted: $ip"    
#    fi
    
#done

#kubectl -n pft delete configMap,deployment,pod,svc --all
