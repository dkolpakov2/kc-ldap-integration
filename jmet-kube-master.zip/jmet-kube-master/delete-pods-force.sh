#!/usr/bin/env bash
#Script created to launch Jmeter tests directly from the current terminal without accessing the jmeter master pod.
#It requires that you supply the path to the jmx file
#After execution, test script jmx file may be deleted from the pod itself but not locally.

# TODO add param to run this shell script:
# ./start_test_loop.sh scripts/test-plan-keycloak-1000.jmx

#Get namesapce variable
#Get Master pod details
username=$(echo $1 | cut -d' ' -f 1)
echo "username=> "$username

# remove svc
kubectl -n pft delete deployment jmeter-agent-$username --grace-period=0 --force
kubectl -n pft delete configMap jmeter-load-test-$username --grace-period=0 --force
kubectl -n pft delete deployment jmeter-server-$username --grace-period=0 --force
kubectl delete svc jmeter-agent-svc-$username --grace-period=0 --force -n pft
kubectl delete hpa jmeter-agent-$username --grace-period=0 --force -n pft

# Get pods
client_IP=$( kubectl get pods -n pft -o=jsonpath='{range .items[*]}{.metadata.name}{"\n"}')
echo 'client-ip-> ' $client_IP
for ip in $(echo $client_IP | sed "s/,/ /g")
    do
    echo "$ip"
    if [[ "$ip" == *"$username"* ]]; then
        kubectl delete pod $ip --grace-period=0 --force -n pft
        echo "deleted: $ip"    
    fi
    
done

# kubectl delete pod  jmeter-agent-6d4d575645-69hhh --grace-period=0 --force -n pft

