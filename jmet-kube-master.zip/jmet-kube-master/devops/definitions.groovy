// Function for Whitesource scan
def ossScan () {
    sh 'propel config set token $PROPEL_PSW'
    script {
        GIT_URL_MOD = sh(returnStdout: true, script: "echo ${GIT_URL} | sed s,github,$GIT_TOKEN@github,g").trim()
        env.SCAN_ID = sh(returnStdout: true, script: "propel oss scan --gitUrl ${GIT_URL_MOD} --gitBranch ${GIT_BRANCH} | jq -r .scanID").trim()
    }
    timeout(60) {
        waitUntil {
            sleep(60)
            return (ossScanComplete("${SCAN_ID}"));
        }
    }
    script {
        env.ossAlerts = sh(returnStdout: true, script: "propel oss report --scanID $SCAN_ID | jq -r '.alerts[0] | length'").trim()
        def alertsFound = ossAlerts.toInteger() - 1
        println alertsFound
        if (alertsFound > 0){
            return error("Alerts found in OSS scan: " + alertsFound)
        }
    }
}

def ossScanComplete(String scanID) {
    def status = sh(returnStdout: true, script: "propel oss status --scanID ${scanID} | jq -r .statusCode").trim()
    return (status != "in-progress")
}

// Function to login ECR
def loginECR(String ecrPass, String awsECR) {
    script {
        boolean condition = true
        int count = 0
        
        while(condition) {
            try {
                count = count + 1
                sh(script: "echo ${ecrPass} | docker login --username AWS --password-stdin ${awsECR}", returnStdout: false)
                condition = false
            } catch(err) {
                println err
                sleep(env.ECR_RETRY_SLEEP_INTERVAL)
                if(count > env.ECR_RETRY_COUNT.toInteger()) {
                    throw err
                }
            }
        }
    }
}

// Function to push docker image
def pushDockerImage(String dockerImageTag) {
    script {
        boolean condition = true
        int count = 0
        
        while(condition) {
            try {
                count = count + 1
                sh(script: "docker push ${dockerImageTag}", returnStdout: false)
                condition = false
            } catch(err) {
                println err
                sleep(env.ECR_RETRY_SLEEP_INTERVAL)
                if(count > env.ECR_RETRY_COUNT.toInteger()) {
                    throw err
                }
            }
        }
    }
}

// Function to create OSS scan URL
def getOSSScanUrl() {
    println 'getting OSS scan reult URL'
    GIT_REPO_NAME = GIT_URL.tokenize('/').last().split("\\.git")[0]
    GIT_ORG_NAME = GIT_URL.tokenize('/')[2]
    OSS_SCAN_RESULT_URL_UPDATED = null

    script {
        try {
            if(env.SCAN_ID != null) {
                OSS_SCAN_RESULT_URL_UPDATED = env.URL_OSS_SCAN_RESULT.replaceAll("GIT_ORG_NAME", GIT_ORG_NAME)
                        .replaceAll("GIT_REPO_NAME", GIT_REPO_NAME)
                        .replaceAll("OSS_SCAN_ID", env.SCAN_ID)
            }
        } catch (MissingPropertyException e) {
            throw e
            //Eat exception. Ignore this exception as it is expected in some cases
        }
    }
    return OSS_SCAN_RESULT_URL_UPDATED
}

// Function to create SonarQube scan URL
def getSonarScanResultUrl() {
    script {
        pom = readMavenPom(file: './pom.xml')
        artifactId = pom.getArtifactId()
        groupId = pom.getGroupId()
        SONARQUBE_SCAN_RESULT_URL = env.URL_SONARQUBE + 'dashboard?id=' + groupId + '%3A' + artifactId
    }
    return SONARQUBE_SCAN_RESULT_URL
}

return this