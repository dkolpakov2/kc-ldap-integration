#!/usr/bin/env bash
#Script created to launch Jmeter tests directly from the current terminal without accessing the jmeter master pod.
#It requires that you supply the path to the jmx file
#After execution, test script jmx file may be deleted from the pod itself but not locally.

working_dir="`pwd`"
echo "work_dir:" $working_dir
tenant=`awk '{print $NF}' "$working_dir/pft_export"`
# Get pods
client_IP=$( kubectl get pods -n pft -o=jsonpath='{range .items[*]}{.metadata.name}{"\n"}')
echo 'client-ip-> ' $client_IP
for ip in $(echo $client_IP | sed "s/,/ /g")
    do
    echo "$ip"
        # Metrics API server in not installed
        #kubectl top pod $ip -n $tenant
        #use linux from inside:
        winpty kubectl exec -it -n $tenant $ip -- sh -c 'echo $(cat /proc/loadavg | awk "{print $1}")'

        #winpty kubectl exec -it -n $tenant $ip -- sh -c 'echo "$(top -bn1 | head -20)"'
        #winpty kubectl exec -it -n $tenant $ip -- sh -c echo $(cat /proc/loadavg | awk '{print $1}') > $working_dir/test_done
done

echo 'done analyzing'
