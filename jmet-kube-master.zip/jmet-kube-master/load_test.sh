#!/bin/bash

#Script created to invoke jmeter test script with the client POD IP addresses
#Script should be run like: ./load_test "path/name the test script in jmx format"
#/jmeter/apache-jmeter-*/bin/jmeter -n -t $1 -Dserver.rmi.ssl.disable=true -R `getent ahostsv4 jmeter-agent-svc | cut -d' ' -f1 | sort -u | awk -v ORS=, '{print $1}' | sed 's/,$//'`
echo "run load_test on server..."
#echo `getent ahostsv4 jmeter-agent-svc | cut -d' ' -f1 | sort -u | awk -v ORS=, '{print $1}' | sed 's/,$//'`
#/jmeter/apache-jmeter-5.0/bin/jmeter -n -t $1 -Jserver.rmi.localport=1099 -l testresults.jtl -Dserver.rmi.ssl.disable=true -R `getent ahostsv4 jmeter-agent-svc | cut -d' ' -f1 | sort -u | awk -v ORS=, '{print $1}' | sed 's/,$//'`
#/jmeter/apache-jmeter-5.0/bin/jmeter -n -t $1 -Jserver.rmi.localport=1099 -l testresults.jtl -Dserver.rmi.ssl.disable=true -R "$2"
jmx=$(echo $1 | cut -d' ' -f 1)
pods=$(echo $1 | cut -d' ' -f 2)
/jmeter/apache-jmeter-5.0/bin/jmeter -n -t $jmx -l testresults.jtl -Dserver.rmi.ssl.disable=true --remotestart $pods
echo "load_test test file: " "$jmx"

# send report to aws s3 bucket