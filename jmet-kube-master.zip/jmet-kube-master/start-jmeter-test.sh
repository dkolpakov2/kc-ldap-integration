#!/usr/bin/env bash

#Script created to launch Jmeter tests directly from the current terminal without accessing the jmeter master pod.
#It requires that you supply the path to the jmx file
#After execution, test script jmx file may be deleted from the pod itself but not locally.
# ./start-jmeter-test.sh scripts/test-plan-keycloak-1000.jmx
# ./start-jmeter-test.sh scripts/DEV-1UserBased-5-10.jmx
# ./start-jmeter-test.sh scripts/dev-test.jmx
# ./start-jmeter-test.sh scripts/QA-test-plan-1UserBased-5-10.jmx

# usage
# ./start-jmeter-test.sh scripts/TaskNotes2.jmx dmitry
# ./start-jmeter-test.sh scripts/TaskNotes2.jmx febi

LOCKFILE='lock.pid'
# check for existing lockfile
	if [ -e "$LOCKFILE" ]; then
# lockfile exists - ensure that it's readable
		[ -r "$LOCKFILE" ] || { echo error: lockfile is not readable; exit 1; }
# ensure that process that created lockfile is no longer running
		kill -0 "`cat "$LOCKFILE"`" 2>/dev/null && { echo error: an instance of this script is already running; exit 1; }
# delete lockfile
		rm -f "$LOCKFILE" || { echo error: failed to delete lockfile; exit 1; }
	fi

# create lockfile
	echo $$ >"$LOCKFILE" || { echo error: failed to create lockfile; exit 1; }

#
JMETER_HOME="/jmeter/apache-jmeter-5.0"
working_dir="`pwd`"
echo "work_dir:" $working_dir
#Get namesapce variable
tenant=`awk '{print $NF}' "$working_dir/pft_export"`
echo "tenant -> " $tenant

# TODO add param to shell
jmx="$1"
[ -n "$jmx" ] || read -p 'Enter path to the jmx file ' jmx
if [ ! -f "$jmx" ];
then
    echo "Test script file was not found in PATH"
    echo "Kindly check and input the correct file path"
    exit
fi

test_name="$(basename "$jmx")"

#Get Master pod details
#jmx=$(echo $1 | cut -d' ' -f 1)
#pods=$(echo $1 | cut -d' ' -f 2)
username=$(echo $2 | cut -d' ' -f 2)
echo "username= "$username
#username=$(kubectl get pods -o=jsonpath='{range .items..metadata}{.name}{"\n"}{end}' | fgrep {print $username})

# save test start time
DATE=`date`
echo $test_name = "test_started->'$DATE'" > $working_dir/test_$username
aws s3 cp $working_dir/test_$username s3://renewables-uai3031357-config-qa/testpft/test_$username --sse-kms-key-id arn:aws:kms:us-east-1:487459321624:key/435837b1-af36-4eab-b10c-31279d4de750 --sse aws:kms --acl bucket-owner-full-control  --no-verify-ssl 
#

master_pod=`kubectl get pod -n pft | grep 'jmeter-server-'$username | awk '{print $1}'`

echo "server master pod ->" $master_pod

# TODO change the test file below kubectl cp somefile.jmx -n pft jmeter-server-79645d88bc-xwlhb:/somefile.jmx
#kubectl cp $jmx -n $tenant $master_pod":/QA-test-plan-1UserBased-5-10.jmx"
kubectl cp $jmx -n $tenant $master_pod":/""$test_name"


echo "jmx file copied!"
echo "test name to run-> " "'$test_name'"
# copy load_test.sh
kubectl cp load_test.sh -n $tenant $master_pod":/load_test.sh"
winpty kubectl exec -it -n $tenant $master_pod -- bash -c 'chmod 755 /load_test.sh'
echo "load_test file copied!"

## Echo Starting Jmeter load test
#pod=$( kubectl get pods -n $tenant -o=jsonpath='{range .items[*]}{.status.podIP}{"\n" " "}')
#name=$(kubectl get pods | awk '{print $1}' | grep -e "dmitry")
#echo "server master pod ->" $name

# get pod names
#pod=$( kubectl get pods -n $tenant -o=jsonpath='{range .items[*]}{.metadata.name}{"\n" " "}')
#
# kubectl get pods -n pft -o=jsonpath='{range .items['jmeter-agent-dmitry']}{.status.podIP}{"\n" " "}'
# kubectl get pods -n pft -o=jsonpath="{range .items[*]}{.metadata.name}{'\t'}{.status.startTime}{'\n'}{end}"
# kubectl get secrets -o jsonpath='{.items[?(@.metadata.name=~/^default-/)]}'

# kubectl get pods -n pft -o=jsonpath='{range .items[agent-$username.*]}{.status.podIP}{"\n" " "}'
# pod=$( kubectl get pods -n $tenant -o=jsonpath='{range .items['agent-dmitry'.*]}{.status.podIP}{"\n" " "}')
deploymentName="jmeter-agent-$username"
#         pod=$( kubectl get pods -n pft -o=jsonpath='{range .items['agent-dmitry'.*]}{.status.podIP}{"\n" " "}')
agentPodName=$(kubectl get pods -n pft -o=jsonpath='{.items[*].metadata.name}{"\n" " "}' | grep -oP "${deploymentName}.*?\s")

echo "agentPods -> $agentPodName"
# kubectl logs ${agentPodName} -n pft 

#kubectl describe pod jmeter-agent-dmitry-56d68d9c75-jzbfk -n pft | grep IP | sed -E 's/IP:[[:space:]]+//'
#kubectl describe pod jmeter-agent-dmitry-56d68d9c75-jzbfk -n pft | grep IP | awk '{print $2}'
# kubectl get pods -n pft -o custom-columns=:metadata.name --no-headers=true --field-selector status.podIP=100.64.124.75
# kubectl get pods -n pft -l app=jmeter-agent-svc-dmitry -o=jsonpath="{range .items[*]}{.status.podIP}{','}{end}"

## Echo Starting Jmeter load test
# OLD->  pod=$( kubectl get pods -n $tenant -o=jsonpath='{range .items[*]}{.status.podIP}{"\n" " "}')
# new 
pod=$(kubectl get pods -n pft -l jmeter_mode=agent-$username -o=jsonpath="{range .items[*]}{.status.podIP}{','}{end}")
pods=$(echo ${pod% *})
echo "$pods"
pod=${pods//[ ]/:1099,}
pods=$(echo ${pod%,*})
echo "PODS-> ""$pods"

# get Server pod
serverName="jmeter-server-$username"
serverPod=$(kubectl get pods -n pft -o=jsonpath='{.items[*].metadata.name}{"\n" " "}' | grep -oP "${serverName}.*?\s")
echo "serverPod -> $serverPod"

# add below line if fails to run on remote server wit ERROR->>  bash: ./load_test.sh: /bin/bash^M: bad interpreter: No such file or directory command terminated with exit code 126
#sed -i -e 's/\r$//' load_test.sh

# OLD-> winpty kubectl exec -it -n $tenant $master_pod -- bash -c './load_test.sh '"'$test_name $pods'" 
# new
winpty kubectl exec -it -n $tenant $serverPod -- bash -c './load_test.sh '"'$test_name $pods'" 

# Copy logs:
JMETER_HOME="/jmeter.log"
JMETER_LOG_RESULTS="/testresults.jtl"
echo 'Copy Server - Master log has been started...'
kubectl -n $tenant cp $master_pod:$JMETER_HOME results$JMETER_HOME
kubectl -n $tenant cp $master_pod:$JMETER_LOG_RESULTS results$JMETER_LOG_RESULTS

echo 'clear - Master Server log is started...'
winpty kubectl -n $tenant exec -it $master_pod -- bash  -c 'rm /testresults.jtl'
echo 'clear summary of master logs is done!'

#  kubectl -n pft cp jmeter-server-79645d88bc-2ffnd:/testresults.jtl results/endure-157000-1pod.jlt
echo 'Server logs have been copied!'
# Copy agent logs
client_IP=$( kubectl get pods -n pft -o=jsonpath='{range .items[*]}{.metadata.name}{"\n"}')
echo 'Copy agent logs has been started...'
echo 'client-ips-> ' $client_IP
JMETER_LOG="/jmeter-server.log"

for ip in $(echo $client_IP | sed "s/,/ /g")
    do
    if [[ "$ip" == *"agent-$username"* ]]; then
        echo "coping from ip-> " "$ip"
        kubectl -n $tenant cp $ip:$JMETER_LOG results/$ip$JMETER_LOG
    fi
done
echo 'Download of agent logs has been competed!'

# Save test done timestamp 
DATE=`date`
echo $test_name = "test_done->'$DATE'" > $working_dir/test_$username

aws s3 cp $working_dir/test_$username s3://renewables-uai3031357-config-qa/testpft/test_$username --sse-kms-key-id arn:aws:kms:us-east-1:487459321624:key/435837b1-af36-4eab-b10c-31279d4de750 --sse aws:kms --acl bucket-owner-full-control  --no-verify-ssl 


# test
# winpty kubectl exec -it -n pft jmeter-server-5646744476-zl969  -- bash
# winpty kubectl exec -it -n pft jmeter-server-5646744476-zl969 -- bash -c './load_test.sh DEV-1UserBased-5-10.jmx jmeter-agent-9c6bdb7db-c7rj9 jmeter-agent-9c6bdb7db-l86xc jmeter-agent-9c6bdb7db-wqfxk jmeter-agent-9c6bdb7db-xxv4z jmeter-agent-9c6bdb7db-xzhnb' 

