#!/usr/bin/env bash
# this below command is done
# helm install --dry-run --debug ./devops
# to package into arch
# helm package ./devops
# unpackage and install:
# helm install example3 devops-0.1.0.tgz --set service.type=NodePort
# update helm

# RUN  ./update-helm.sh febi
echo "set update helm for user: "
username=$(echo $1 | cut -d' ' -f 1)
echo "$username"

echo
tenant="pft"
# Login with the following credentials 
#echo Username: user
#  echo Password: $(kubectl get secret --namespace default happy-panda-wordpress -o jsonpath="{.data.wordpress-password}" | base64 --decode)
# helm show values devops

# helm list  --deployed
# helm repo list
# APP_NAME = grep -w 'name' devops/values.yaml | awk {'print \$NF'}
QA_POD_CONFIG="devops/values.yaml"
DEPLOYMENT_TIME_OUT="1m0s"

echo "****Deploying to PFT Cluster ****"
helm upgrade --install --atomic $username ./devops \
    --set application.tag=$username,application.name=$username \
    -f $QA_POD_CONFIG --namespace=pft \
    --timeout $DEPLOYMENT_TIME_OUT 
    #\    --kubeconfig $CLUSTER_CONFIG \
    #--kube-context $EKS_CLUSTER_DEV

echo "Printout Of the $tenant Objects"
echo
kubectl get -n $tenant all
echo namespace = $tenant > $working_dir/pft_export

#helm upgrade devops --dry-run --debug  --values values.yaml ./devops --set application.name=$username -n pft 
#helm install --dry-run --debug ./devops --set application.name=$username devops -n pft 
#helm install --dry-run --debug ./devops --set application.name=$username devops -n pft 
#helm install --dry-run --debug ./devops --set application.name=$username devops -n pft 

# get logs
deploymentName="jmeter-agent-$username"
         pod=$( kubectl get pods -n pft -o=jsonpath='{range .items[*]}{.status.podIP}{"\n" " "}')
agentPodName=$(kubectl get pods -n pft -o=jsonpath='{.items[*].metadata.name}{"\n" " "}' | grep -oP "${deploymentName}.*?\s")

echo "agentPods -> $agentPodName"
# kubectl logs ${agentPodName} -n pft 

deploymentName="jmeter-server-$username"
serverPodName=$(kubectl get pods -n pft -o=jsonpath="{.items[*].metadata.name}" | grep -oP "${deploymentName}.*?\s")
echo "serverPod -> $serverPodName"


# kubectl get pods -n pft -o=jsonpath="{.items[*].status.hostIP}" | grep -oP "agent-dmitry.*?\s"
# kubectl get pods -n pft -o=jsonpath="{.items[*].metadata.name}" | grep -oP "agent-dmitry.*?\s"
# kubectl get pods -o=jsonpath='{range .items..metadata}{.name}{"\n"}{end}' | fgrep agent-dmitry

#not working:  kubectl get pods -n pft -o json  | jq -r '.items[] | select(.status.phase != "Running" or ([ .status.conditions[] | select(.type == "Ready" and .status == "False") ] | length ) == 1 ) | .metadata.namespace + "/" + .metadata.name'
# Exclude dmitry: kubectl get pods -n pft -o wide --sort-by=.metadata.name | grep -Ev "dmitry"
# Include dmitry: kubectl get pods -n pft  --sort-by=.metadata.name | grep "agent-dmitry"

# Information available via fieldRef:
# spec.nodeName - the node’s name
# status.hostIP - the node’s IP
# metadata.name - the pod’s name
# metadata.namespace - the pod’s namespace
# status.podIP - the pod’s IP address
# spec.serviceAccountName - the pod’s service account name
# metadata.uid - the pod’s UID
# metadata.labels['<KEY>'] - the value of the pod’s label <KEY> (for example, metadata.labels['mylabel']); available in Kubernetes 1.9+
# metadata.annotations['<KEY>'] - the value of the pod’s annotation <KEY> (for example, metadata.annotations['myannotation']); available in Kubernetes 1.9+
# kubectl get pods -n pft -o jsonpath="{.items[] | select(.status.phase != 'Running' or ([ .status.conditions[] | select(.type == 'Ready' and .status == 'False') ] | length ) == 1 ) | .metadata.namespace + '/' + .metadata.name"



